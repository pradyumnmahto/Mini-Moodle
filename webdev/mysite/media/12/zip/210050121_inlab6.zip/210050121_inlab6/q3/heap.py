class Heap:
    """The heap is a data structure to store data such that it is very easy to access the least element
    
    :param H: list holding elements
    :type H: list
    :param n: no of elements
    :type n: int
    :param M: maximum no of elements
    :param M: int
    """
    def __init__(self, cap):
        """Constructor method
        
        :param cap: max elements
        :type cap: int
        """
        self.H = []
        self.n = 0
        self.M = cap
    
    def parent(self, i):
        """Finds parent
        
        :param i: index of which parent is to be found
        :type i: int
        :return: parent index
        :rtype: int
        """
        return (i - 1) // 2
    
    def left(self, i):
        """Finds left child
        
        :param i: index of which child is to be found
        :type i: int
        :return: left child index
        :rtype: int
        """
        return (2 * i)+1
    
    def right(self, i):
        """Finds right child
        
        :param i: index of which child is to be found
        :type i: int
        :return: right child index
        :rtype: int
        """
        return 2 * (i + 1)
    
    def insert(self, val):
        """inserts element
        
        :param val: value to be inserted
        :type i: int
        """
        if self.n != self.M:
            self.H[self.n] = val
            i = self.n
            self.n += 1
            while i != 0 and self.H[self.parent(i)] > self.H[i]:
                self.H[i], self.H[self.parent(i)] = self.H[self.parent(i)], self.H[i]
                i = self.parent(i)
    
    def min(self):
        """returns min element
        
        :return: value of min element
        :rtype: int
        """
        if (self.n != 0):
            return self.H[0]
        return -1
    
    def Heapify(self, root):
        """Moves elements to make the structure heap again
        
        :param root: index of root
        :type root: int
        """
        l = self.left(root)
        r = self.right(root)
        s = root
        if (l < self.n and self.H[l] < self.H[root]):
            s = l
        if (r < self.n and self.H[r] < self.H[s]):
            s = r
        if s != root:
            self.H[root], self.H[s] = self.H[s], self.H[root]
            self.Heapify(s)
    
    def deleteMin(self):
        """Deletes the min element
        """

        if self.n > 0:
            if self.n == 1:
                self.H = []
                self.n = 0
            else:
                self.n -= 1
                self.H[0] = self.H[self.n]
                self.Heapify(0)
