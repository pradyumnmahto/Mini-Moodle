
def binarySearch(arr, val):
    """Searches for a value in a sorted array.
    
    :param arr: a sorted array in which the value is to be searched
    :type arr: list
    :param val: the value to be searched for
    :type val: int
    :return: the index of the element found otherwise -1
    :rtype: int
    """
    l = 0
    r = len(arr) - 1
    while l < r:
        m = l + (r - l) // 2
        if arr[m] > val:
            r = m
            return binarySearch(arr[l:r+1],val)
        elif arr[m] < val:
            l = m
            return binarySearch(arr[l:r+1],val)
        else:
            return m
    return -1
