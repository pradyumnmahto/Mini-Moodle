basic module
============

.. automodule:: basic
    :members:
    :undoc-members:
    :show-inheritance:
