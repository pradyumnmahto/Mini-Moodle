var searchData=
[
  ['tail_87',['tail',['../classSinglyLinkedList.html#aa9eda1214c82e9e09e60ff5514bdbc10',1,'SinglyLinkedList::tail()'],['../classDoublyLinkedList.html#a65102ebd8ef6a7a70c2fb3d3ea505f19',1,'DoublyLinkedList::tail()']]]
];
