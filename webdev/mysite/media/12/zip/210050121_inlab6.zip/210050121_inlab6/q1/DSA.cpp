/**
 * @file DSA.cpp
 * @author Pratham Garg
 * @brief This file contains some data structures like lists and trees , including their detailed structures and member functions 
 * @version 0.1
 * @date 2022-09-21
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <bits/stdc++.h>
#define ll long long int
#define vi vector<int>
#define vll vector<ll>
using namespace std;

/* ------------------------------- Data Structures ---------------------------------- */

// ------------------------------- Singly Linked List -----------------------------
/**
 * @brief This is a structure that contains one instance of data and holds the address to a similar structure to it.
 * 
 */
class SinglyLinkedListNode {

    public:

        ll data;///< Holds the actual value to be stored
        SinglyLinkedListNode* next;///< Holds the address to the next node 
        /**
         * Construct a new Singly Linked List Node object.Sets the data to -1 and next node to null.
         * 
         */
        SinglyLinkedListNode () {
            data = -1;
            next = NULL;
        }
        /**
         * Construct a new Singly Linked List Node object.Sets the data equal to parameter val and next node to null.
         * @param val
         */
        SinglyLinkedListNode (ll val) {
            data = val;
            next = NULL;
        }

};
/**
 * @brief Function for easy accessing of data of the class
 * @param out 
 * @param node 
 * @return ostream& 
 */
ostream& operator<<(ostream &out, const SinglyLinkedListNode &node) {
    return out << node.data;
}
/**
 * @brief A chain of the SinglyLinkedNode
 * This class uses the node class created earlier to store a chain of data. The data can be stored in an ordered manner without any waste of space.
 * 
 */
class SinglyLinkedList {

    public:
        
        SinglyLinkedListNode *head/**stores the pointer to the statring of the chain*/, *tail;///<stores the pointer to the statring of the chain;
        /**
         * Construct a new Singly Linked List object
         * Sets both head and tail to null
         */
        SinglyLinkedList () {
            head = NULL;
            tail = NULL;
        }
        /**
         * Inserts a new node into the list
         * 
         * @param data 
         */
        void insert (ll data) {
            SinglyLinkedListNode *node = new SinglyLinkedListNode(data);
            if (head == NULL) {
                head = node;
            }
            else {
                tail -> next = node;
            }
            tail = node;
        }
        /**
         * Finds the node 
         * 
         * @param data 
         * @return SinglyLinkedListNode* 
         */
        SinglyLinkedListNode* find (ll data) {
            SinglyLinkedListNode *ptr = head, *prev = NULL;
            while (ptr != NULL && ptr -> data != data) {
                prev = ptr;
                ptr = ptr -> next;
            }
            return prev;
        }
        /**
         * @brief Deletes the value if its present in the list 
         * 
         * @param data 
         * @return true if value found else false
         */
        bool deleteVal (ll data) {
            SinglyLinkedListNode *prev = find(data);
            if (prev -> next == NULL) {
                return false;
            }
            prev -> next -> next = prev -> next;
            return true;
        }
        /**
         * @brief Prints all the list node elements
         * 
         * @param sep 
         */
        void printer (string sep = ", ") {
            SinglyLinkedListNode *ptr = head;
            cout << "[";
            while (ptr != NULL) {
                cout << *ptr;
                ptr = ptr -> next;
                if (ptr != NULL) {
                    cout << sep;
                }
            }
            cout << "]\n";
        }
        /**
         * @brief rotates the list by 180 degree
         * 
         */
        void reverse () {
            SinglyLinkedListNode *ptr = head, *prev = NULL;
            while (ptr != NULL) {
                SinglyLinkedListNode *ptr2 = ptr -> next;
                ptr -> next = prev;
                prev = ptr;
                ptr = ptr2;
            }
            tail = ptr;
            head = prev;
        }

};
/**
 * @brief Merges 2 LInkedLists
 * 
 * @param list1 
 * @param list2 
 * @return SinglyLinkedList 
 */
SinglyLinkedList merge (SinglyLinkedList list1, SinglyLinkedList list2) {
    SinglyLinkedList merged;
    SinglyLinkedListNode *head1 = list1.head, *head2 = list2.head;
    while (head1 != NULL && head2 != NULL) {
        if (head1 -> data < head2 -> data) {
            merged.insert(head1 -> data);
            head1 = head1 -> next;
        }
        else {
            merged.insert(head2 -> data);
            head2 = head2 -> next;
        }
    }
    if (head1 == NULL && head2 != NULL) {
        merged.tail -> next = head2;
    }
    if (head2 == NULL && head1 != NULL) {
        merged.tail -> next = head1;
    }
    return merged;
}

// ------------------------------- Doubly Linked List -----------------------------
/**
 * @brief This is linked list which contains pointers both 
 * 
 */
class DoublyLinkedListNode {

    public:
        
        ll data;///< Holds the actual value to be stored
        DoublyLinkedListNode *next/**pointer to next node*/, *prev;///<pointer to previous node
        /**
         * @brief Construct a new Doubly Linked List Node object
         * Set data to -1 and both pointers to null
         */
        DoublyLinkedListNode () {
            data = -1;
            next = NULL;
            prev = NULL; 
        }
        /**
         * @brief Construct a new Doubly Linked List Node object
         * Set data to val and both pointers to null
         * @param val 
         */
        DoublyLinkedListNode (ll val) {
            data = val;
            next = NULL;
            prev = NULL;
        }

};
/**
 * @brief Function for easy accessing of data of the class
 * @param out 
 * @param node 
 * @return ostream& 
 */
ostream& operator<<(ostream &out, const DoublyLinkedListNode &node) {
    return out << node.data;
}
/**
 * @brief List using DoublyLinkedNode
 * 
 */
class DoublyLinkedList {

    public:
        
        DoublyLinkedListNode *head/** pointer to head*/, *tail;///< pointer to tail;
        /**
        * @brief Construct a new Doubly Linked List object
        * 
        */
        DoublyLinkedList () {
            head = NULL;
            tail = NULL;
        }
        /**
         * @brief  inserts node
         * 
         * @param data 
         */
        void insert (ll data) {
            DoublyLinkedListNode *node = new DoublyLinkedListNode(data);
            if (head == NULL) {
                head = node;
            }
            else {
                tail -> next = node;
                node -> prev = tail;
            }
            tail = node;
        }
        /**
         * @brief prints the list
         * 
         * @param sep 
         */
        void printer (string sep = ", ") {
            DoublyLinkedListNode *ptr = head;
            cout << "[";
            while (ptr != NULL) {
                cout << *ptr;
                ptr = ptr -> next;
                if (ptr != NULL) {
                    cout << sep;
                }
            }
            cout << "]\n";
        }
        /**
         * @brief reverses the list
         * 
         */
        void reverse () {
            DoublyLinkedListNode *ptr = head, *pr = NULL;
            while (ptr != NULL) {
                DoublyLinkedListNode *ptr2 = ptr -> next;
                if (ptr2 != NULL) {
                    ptr2 -> prev = ptr;
                }
                ptr -> next = pr;
                ptr -> prev - ptr2;
                pr = ptr;
                ptr = ptr2;
            }
            tail = ptr;
            head = pr;
        }

};

// ------------------------------- Binary Search Tree -----------------------------
/**
 * @brief Node containing value and pointers to its left and child
 * 
 */
class BSTNode {

    public:

        ll info/** data stored*/, level;///<distance from root
        BSTNode *left/** pointer to left child*/, *right;///< pointer to right child
        /**
         * @brief Construct a new BSTNode object
         * 
         * @param val 
         */
        BSTNode (ll val) {
            info = val;
            level = 0;
            left = NULL;
            right = NULL;
        }

};
/**
 * @brief Prints out the value of a bst node
 * 
 * @param out 
 * @param node 
 * @return ostream& 
 */
ostream& operator<<(ostream &out, const BSTNode &node) {
    return out << node.info;
}
/**
 * @brief  Uses the BSTNODE to create a tree
 * 
 */
class BinarySearchTree {

    public:
        
        BSTNode *root;///< pointer to the first element
        
        enum order {PRE, IN, POST};///< type of traversal
        /**
         * @brief Construct a new Binary Search Tree object
         * 
         */
        BinarySearchTree () {
            root = NULL;
        }
        /**
         * @brief inserts a new node in the tree
         * 
         * @param val 
         */
        void insert(ll val) {
            if (root == NULL) {
                root = new BSTNode(val);
            }
            else {
                BSTNode *ptr = root;
                while (true) {
                    if (val < ptr -> info) {
                        if (ptr -> left != NULL) {
                            ptr = ptr -> left;
                        }
                        else {
                            ptr -> left = new BSTNode(val);
                            break;
                        }
                    }
                    else if (val > ptr -> info) {
                        if (ptr -> right != NULL) {
                            ptr = ptr -> right;
                        }
                        else {
                            ptr -> right = new BSTNode(val);
                            break;
                        }
                    }
                    break;
                }
            }
        }
        /**
         * @brief traverses the tree
         * 
         * @param T 
         * @param tt 
         */
        void traverse (BSTNode* T, order tt) {
            if (tt == PRE) {
                cout << T << endl;
                if (T -> left != NULL) {
                    traverse(T -> left,tt);
                }
                if (T -> right != NULL) {
                    traverse(T -> right,tt);
                }
            }
            else if (tt == IN) {
                if (T -> left != NULL) {
                    traverse(T -> left,tt);
                }
                cout << T << endl;
                if (T -> right != NULL) {
                    traverse(T -> right,tt);
                }
            }
            else if (tt == POST) {
                if (T -> left != NULL) {
                    traverse(T -> left,tt);
                }
                if (T -> right != NULL) {
                    traverse(T -> right,tt);
                }
                cout << T << endl;
            }
        }
        /**
         * @brief finds out the type of tree
         * 
         * @param T 
         * @return ll 
         */
        ll height(BSTNode *T) {
            if (T -> left == NULL && T -> right == NULL) {
                return 0;
            }
            else if (T -> right == NULL) {
                return 1 + height(T -> left);
            }
            else if (T -> left == NULL) {
                return 1 + height(T -> right);
            }
            return max(1 + height(T -> left),1 + height(T -> right));
        }

};

// ------------------------------- Suffix Trie -----------------------------
/**
 * @brief data structure tp store strings and easy counting of patterns
 * 
 */
class Trie {

    public:
        
        ll count;///< number of occurences of a pattern
        map<char,Trie*> nodes;///< map from a char to its Trie
        /**
         * @brief Construct a new Trie object
         * 
         */
        Trie () {
            count = 0;
            nodes = map<char,Trie*>();
        }
        /**
         * @brief finds the trie corresponding to a character
         * 
         * @param T 
         * @param c 
         * @return true 
         * @return false 
         */
        bool find(Trie* T, char c) {
            return ((T -> nodes).find(c) != (T -> nodes).end());
        }
        /**
         * @brief inserts a string
         * 
         * @param s 
         */
        void insert(string s) {
            Trie* ptr = this;
            for (auto c: s) {
                if (!find(ptr,c)) {
                    (ptr -> nodes)[c] = new Trie();
                }
                ptr = (ptr -> nodes)[c];
                (ptr -> count)++;
            }
        }
        /**
         * @brief checks prefix in a trie
         * 
         * @param s 
         * @return true 
         * @return false 
         */
        bool checkPrefix(string s) {
            Trie* ptr = this;
            for (ll i = 0; i < s.length(); i++) {
                if (!find(ptr,s[i])) {
                    if (i == s.length() - 1) {
                        (ptr -> nodes)[s[i]] = NULL;
                    }
                    else {
                        (ptr -> nodes)[s[i]] = new Trie();
                    }
                }
                else if ((ptr -> nodes)[s[i]] == NULL or i == s.length() - 1) {
                    return true;
                }
                ptr = (ptr -> nodes)[s[i]];
            }
            return false;
        }
        /**
         * @brief counts the no of prefixes
         * 
         * @param s 
         * @return ll 
         */
        ll countPrefix(string s) {
            bool found = true;
            Trie* ptr = this;
            for (auto c: s) {
                if (find(ptr,c)) {
                    ptr = (ptr -> nodes)[c];
                }
                else {
                    found = false;
                    break;
                }
            }
            if (found) {
                return ptr -> count;
            }
            return 0;
        }

};

/**
 * @brief class of Heap data structure 
 * 
 */
class heap{
    public:
    
    int* arr;///< The pointer to array containing the elements
    int cap;///< max no of elemenst
    int n;///< current no of elements
    /**
     * Construct a new heap object
     * @param cap 
     */
    heap(int cap){
        this->cap=cap;
        n=0;
        arr=new int[cap];
    }
    /**
     * Returns parent of the given index
     * @param i 
     * @return int 
     */
    int parent(int i){
        int x=(i-1)/2;
        return x;
    }
    /**
     * returns left child 
     * @param i 
     * @return int 
     */
    int left(int i){
      
        return (2 * i)+1;
    }
    
    /**
     * returns right child
     * @param i 
     * @return int 
     */
    int right(int i){
      
        return (2 * i)+2;
    }
    /**
     * inserts a new element
     * 
     * @param val 
     */
    void insert(int  val){
        if (n != cap){
            arr[n] = val;
            int i = n;
            n += 1;
            while (i != 0 && arr[parent(i)] > arr[i]){
                int x=arr[i];
                arr[i]= arr[parent(i)];
                arr[parent(i)]=x;
                i = parent(i);
            }
        }
    }
    /**
     * @brief returns the minimum element
     * 
     * @return int 
     */
    int min(){
        
        if (n != 0)return arr[0];
        return -1;
    }
    /**
     * @brief Makes the array heap again
     * 
     * @param root 
     */
    void Heapify(int root){
        int l = left(root);
        int r = right(root);
        int s = root;
        if (l < n && arr[l] < arr[root])s = l;
        if (r < n && arr[r] < arr[s])s = r;
        if (s != root){
            int x=arr[root];
            arr[root]=arr[s];
            arr[s]=x;
            Heapify(s);
        }
    }
    /**
     * @brief deletes minimum element
     * 
     */
    void deleteMin(){
        
        if (n > 0){
            if (n == 1){
                n = 0;
            }
            else{
                n -= 1;
                arr[0] = arr[n];
                Heapify(0);
            }
        }
    }
};