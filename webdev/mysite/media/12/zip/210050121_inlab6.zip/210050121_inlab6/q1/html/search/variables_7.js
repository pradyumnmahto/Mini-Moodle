var searchData=
[
  ['prev_84',['prev',['../classDoublyLinkedListNode.html#a71975a67e453e90aa017f218cde95535',1,'DoublyLinkedListNode']]]
];
