var searchData=
[
  ['head_77',['head',['../classSinglyLinkedList.html#a004deeaf32ec4f6c3508bbb785f1910a',1,'SinglyLinkedList::head()'],['../classDoublyLinkedList.html#ab85c831a1463a976160fb2bd55e0c82e',1,'DoublyLinkedList::head()']]]
];
