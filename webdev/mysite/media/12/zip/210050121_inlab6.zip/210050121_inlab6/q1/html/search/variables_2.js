var searchData=
[
  ['data_76',['data',['../classSinglyLinkedListNode.html#a56aa6be35dc7d1c8a4efe43346248236',1,'SinglyLinkedListNode::data()'],['../classDoublyLinkedListNode.html#a72d96ffa5352b4d8548467560519e026',1,'DoublyLinkedListNode::data()']]]
];
